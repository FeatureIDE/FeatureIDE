/**
 * Provides JUnit v3.x command line based tool to run tests.
 */
package junit.textui;