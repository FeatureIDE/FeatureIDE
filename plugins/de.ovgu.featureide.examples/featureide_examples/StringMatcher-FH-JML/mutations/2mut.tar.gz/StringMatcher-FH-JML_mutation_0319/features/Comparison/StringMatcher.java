
public  class  StringMatcher {

	//@public ghost boolean compare;
	int bla;
	


	
	/*@
	  @ requires a != null && b != null; 
	  @ ensures  \result <==> false;
	  @*/
	public boolean compare(String a, String b){
	
		//@ set compare=true;
		return  true;
	}
	
}