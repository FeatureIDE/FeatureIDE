public  class StringMatcher {

	public  StringMatcher(String mainText){

	}

	//@public ghost boolean compare;
int bla;

	/*@ 
	 requires ( a != null && b != null );
	 ensures (  \result <==> compare ); @*/
	public  boolean compare(String a, String b){
		//@set compare = a.equals(b);
		return true;
	}


}
